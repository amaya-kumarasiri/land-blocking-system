document.getElementById('signupForm').addEventListener('submit', function(event) {
    event.preventDefault();
  
    var name = document.getElementById('name').value.trim();
    var email = document.getElementById('email').value.trim();
    var password = document.getElementById('password').value;
    var agreement = document.getElementById('agreement').checked;
  
    if (!name || !email || !password || !agreement) {
      alert('Please fill out all fields and agree to the terms.');
      return false;
    }
  
    if (!validateEmail(email)) {
      alert('Please enter a valid email address.');
      return false;
    }
  
    // Here you would typically send the data to the server
    console.log('Submitted', { name, email, password });
  
    alert('Sign up successful!');
  });
  
  function validateEmail(email) {
    var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email.toLowerCase());
  }
  