document.getElementById('go-btn').addEventListener('click', function() {
    window.location.href = 'destination.html'; // Replace with your destination page
  });
  