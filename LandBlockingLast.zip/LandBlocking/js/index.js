document.getElementById('playButton').addEventListener('click', function() {
    // alert('Play button clicked!');
    window.location.href = '../html/signin.html';
  });
  