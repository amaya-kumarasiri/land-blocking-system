document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
    
    // Simple validation
    if(username === '' || password === '') {
      alert('Please enter both username and password.');
      return false;
    }
    
    // Here, you would handle the login with a server
    console.log('Submitted', { username, password });
    
    // Simulate login success
    alert('Login successful!');
    
    
    return true;
  });
  
  // Simulate social login buttons
  document.getElementById('googleLogin').addEventListener('click', function() {
    alert('Google login clicked!');
  });
  
  document.getElementById('facebookLogin').addEventListener('click', function() {
    alert('Facebook login clicked!');
  });
  