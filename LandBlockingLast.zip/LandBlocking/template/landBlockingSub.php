<?php
require 'connection.php';

if (isset($_POST["submit"])) {
    $name = $_POST["name"];
    $blocks = $_POST["blocks"];
    $acres = $_POST["acres"];

    if ($_FILES["image"]["error"] !== UPLOAD_ERR_OK) {
        echo "<script> alert('Failed to upload image. Please try again.'); </script>";
    } else {
        $fileName = $_FILES["image"]["name"];
        $fileSize = $_FILES["image"]["size"];
        $tmpName = $_FILES["image"]["tmp_name"];

        $validImageExtension = ['jpg', 'jpeg', 'png'];
        $imageExtension = pathinfo($fileName, PATHINFO_EXTENSION);

        if (!in_array(strtolower($imageExtension), $validImageExtension)) {
            echo "<script>alert('Invalid Image Extension');</script>";
        } else if ($fileSize > 1000000) {
            echo "<script>alert('Image Size Is Too Large');</script>";
        } else {
            $newImageName = uniqid() . '.' . $imageExtension;
            $uploadPath = 'img/' . $newImageName;

            if (move_uploaded_file($tmpName, $uploadPath)) {
                // Insert data into database
                $sql = "INSERT INTO tb_upload (name, blocks, image) VALUES (?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("sis", $name, $blocks, $newImageName);

                if ($stmt->execute()) {
                    // Data inserted successfully
                    // Redirect to the determined destination
                    $destination = 'default.html'; // default destination

                    // Navigate based on both blocks and acres values
                    if ($blocks == 2 && $name >= 1 && $name <= 50) {
                        $destination = '../template/plan/newPlanview copy 2.html';
                    } elseif ($blocks == 3 && $name > 50 && $name <= 100) {
                        $destination = '../template/plansnew/newPlanview copy 3b.html';
                    } 
                    elseif ($blocks == 2 && $name > 50 && $name <= 100) {
                      $destination = '../template/plansnew/newPlanview copy 2b.html';
                  } 
                  elseif ($blocks == 4 && $name > 50 && $name <= 100) {
                    $destination = '../template/plansnew/newPlanview copy 4b.html';
                } 
                    elseif ($blocks == 3 && $name > 1 && $name <= 50) {
                      $destination = '../template/plan/newPlanview copy 3.html';
                  } elseif ($blocks == 4 && $name > 1 && $name <= 50) {
                    $destination = '../template/plan/newPlanview copy 4.html';
                } elseif ($blocks == 5 && $name > 1 && $name <= 50) {
                  $destination = '../template/plan/newPlanview copy 5.html';
              } elseif ($blocks == 6 && $name > 1 && $name <= 50) {
                $destination = '../template/plan/newPlanview copy 6.html';
            } elseif ($blocks == 7 && $name > 1 && $name <= 50) {
              $destination = '../template/plan/newPlanview copy 7.html';
          } elseif ($blocks == 8 && $name > 1 && $name <= 50) {
            $destination = '../template/plan/newPlanview copy 8.html';
        } elseif ($blocks == 9 && $name > 1 && $name <= 50) {
          $destination = '../template/plan/newPlanview copy 9.html';
      } elseif ($blocks == 10 && $name > 1 && $name <= 50) {
        $destination = '../template/plan/newPlanview copy 10.html';
    }

                    header("Location: $destination");
                    exit(); // Ensure no further code execution after redirection
                } else {
                    // Error occurred during insertion
                    echo "Error: " . $stmt->error;
                }
            } else {
                echo "<script>alert('Failed to move uploaded file. Please try again.');</script>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Land Blocking System</title>
  <link rel="stylesheet" href="../css/landBlockingMain.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
      background: url('path_to_your_blurred_image.jpg') center/cover no-repeat;
    }

    .container {
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      position: relative; /* To position children relative to the container */
      z-index: 1; /* Ensure the container is above the background image */
    }

    .card {
      width: 300px;
      padding: 20px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      background: #fff;
      border-radius: 8px;
    }

    .custom-file-upload {
      border: 1px solid #ccc;
      display: inline-block;
      padding: 6px 12px;
      cursor: pointer;
      margin-top: 20px;
    }

    .custom-text-input, .custom-select {
      width: 100%;
      padding: 10px;
      margin-top: 15px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }

    .green-button {
      background-color: #4CAF50;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      display: block;
      width: 100%;
      margin-top: 20px;
    }

    /* Styling for the blurred background images */
    .background-images {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 0; /* Ensure it's behind the container */
      display: flex;
      justify-content: space-between; /* To distribute the images evenly */
    }

    .background-image {
      flex: 0 0 30%; /* Adjust width of each image as needed */
      background-size: cover;
      background-position: center;
      filter: blur(5px); /* Apply blur effect */
    }
  </style>
</head>
<body>
  <!-- Background images -->
  <div class="background-images">
    <div class="background-image" style="background-image: url('../images/index2.jpeg');"></div>
    <div class="background-image" style="background-image: url('../images/signup.jpg');"></div>
    <div class="background-image" style="background-image: url('../images/signin.jpeg');"></div>
  </div>

  <div class="container">
    <div class="card">
      <center><h3 class="card-title">Upload Land Plan</h3></center>
      <form action="" method="post" enctype="multipart/form-data">
        <label for="file-upload" class="custom-file-upload">
          <i class="fas fa-cloud-upload-alt"></i> Upload Image
        </label>
        <input id="file-upload" type="file" name="image" style="display: none;">
        <input type="text" placeholder="Enter Acres" class="custom-text-input" name="name" required>
        <br><br>
        <label for="blocks">No.of Blocks: </label>
        <select class="custom-select" name="blocks">
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
          <option value="9">9</option>
          <option value="10">10</option>
          <!-- Additional options can be added here -->
        </select>
        <button type="submit" name="submit" class="green-button">Submit Data</button>
      </form>
    </div>
  </div>
</body>
</html>

