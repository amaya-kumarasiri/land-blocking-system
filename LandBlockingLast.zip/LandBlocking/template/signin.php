<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login Page</title>
<link rel="stylesheet" href="../css/signin.css">
<style>
  body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background-color: #f5f5f5;
  }

  .login-container {
    background-color: white;
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1); /* Add box shadow for premium look */
    border: 1px solid #ccc; /* Add border for premium look */
    text-align: center;
    border: 2px solid #ddd; /* Add thin frame around the form */
  }

  .login-container h1 {
    margin-bottom: 20px;
  }

  .social-login {
    margin-bottom: 20px;
  }

  .social-login button {
    padding: 10px 20px;
    margin-right: 10px;
    border: none;
    border-radius: 20px;
    background-color: #007BFF;
    color: white;
    cursor: pointer;
  }

  .social-login button:last-child {
    margin-right: 0;
  }

  input[type="text"],
  input[type="password"],
  button[type="submit"] {
    width: calc(100% - 22px);
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 10px;
    outline: none;
  }

  button[type="submit"] {
    background-color: #007BFF;
    color: white;
    border: none;
    border-radius: 20px;
    cursor: pointer;
  }

  button[type="submit"]:hover {
    background-color: #0056b3;
  }

  p {
    margin-top: 20px;
  }

  p a {
    color: #007BFF;
    text-decoration: none;
  }

  p a:hover {
    text-decoration: underline;
  }
</style>
</head>
<body>

<?php
@include 'config.php';

session_start();

if (isset($_POST['submit'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $pass = md5($_POST['password']);

    $select = "SELECT * FROM user_form WHERE email = '$email' AND password = '$pass'";
    $result = mysqli_query($conn, $select);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $_SESSION['user_name'] = $row['name'];
        $_SESSION['user_type'] = $row['user_type'];
        header('location: landBlockingMain.html'); // Redirect to the main page
    } else {
        echo '<p class="error-msg">Incorrect username or password</p>';
    }
}
?>

    <div class="left-container">
        
    </div>

<div class="login-container">
  <h1>LAND BLOCKING SYSTEM</h1>
  <p>Welcome! Select a method to log in...</p>

  <div class="social-login">
    <button id="googleLogin">google</button>
    <button id="facebookLogin">facebook</button>
  </div>

  <p>or login with</p>

  <form method="post" action="" style="text-align: center; padding: 20px;">
    <input type="text" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit" name="submit">Login</button>
</form>

  <p>Don't have an account? <a href="./register_form.php">Sign up</a></p>
</div>

</body>
</html>
