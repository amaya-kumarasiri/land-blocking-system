<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Land Blocking System</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.20/dist/sweetalert2.min.css" rel="stylesheet">
</head>

<body  class="bg-cover bg-center">
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js" integrity="sha512-AA1Bzp5Q0K1KanKKmvN/4d3IRKVlv9PYgwFPvm32nPO6QS8yH1HO7LbgB1pgiOxPtfeg5zEn2ba64MUcqJx6CA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- Navigation Menu -->
    <nav class="py-4 ">
        <div class="container mx-auto flex justify-between items-center px-4">
            <a href="../template/about.html" class="text-blue-600 hover:text-blue-800">About</a>
            <a href="../template/contact.html" class="text-blue-600 hover:text-blue-800">Contact</a>
            <a href="../template/index.html" class="text-blue-600 hover:text-blue-800">Home</a>
        </div>
    </nav>

    <div class="container mx-auto flex justify-center items-center flex-wrap gap-8 py-8">
        <form  method="post" enctype="multipart/form-data" class="space-y-6">
            <div class="flex flex-wrap justify-center gap-8">

                <div class="bg-cover bg-center relative w-96 h-96 rounded-lg overflow-hidden shadow-lg">
                    <div class="card-overlay absolute inset-0 bg-black opacity-40"></div>
                    <div class="card-body relative z-10 text-white p-6">
                        <h5 class="card-title text-3xl font-bold mb-6 text-center">Land Plan</h5>
                        <label for="file-upload" class="block bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-6 rounded cursor-pointer mb-6 text-center">
                            <i class="fas fa-cloud-upload-alt mr-2"></i> Upload File
                            <input id="file-upload" type="file" name="file" class="hidden">
                        </label>
                    </div>
                </div>

                <div class="bg-cover bg-center relative w-96 h-96 rounded-lg overflow-hidden shadow-lg">
                    <div class="card-overlay absolute inset-0 bg-black opacity-40"></div>
                    <div class="card-body relative z-10 text-white p-6">
                        <h5 class="card-title text-3xl font-bold mb-6 text-center">Land Area</h5>
                        <input type="text" name="land_area" placeholder="Enter acres" class="custom-input mb-6 block w-full px-4 py-3 rounded-lg bg-gray-200 border-transparent focus:border-gray-500 focus:bg-white focus:ring-0 text-black">
                    </div>
                </div>

                <div class="bg-cover bg-center relative w-96 h-96 rounded-lg overflow-hidden shadow-lg">
                    <div class="card-overlay absolute inset-0 bg-black opacity-40"></div>
                    <div class="card-body relative z-10 text-white p-6">
                        <h5 class="card-title text-3xl font-bold mb-6 text-center">No. of Blocks Needed</h5>
                        <select name="blocks_needed" class="custom-select mb-6 block w-full px-4 py-3 rounded-lg bg-gray-200 border-transparent focus:border-gray-500 focus:bg-white focus:ring-0 text-black">
    <option value="2">2</option>
    <option value="3">3</option>
    <option value="4">4</option>
    <option value="5">5</option>
    <option value="6">6</option>
    <option value="7">7</option>
    <option value="8">8</option>
    <option value="9">9</option>
    <option value="10">10</option>
</select>

                    </div>
                </div>

            </div>

            <div class="text-center">
                <button type="submit" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-6 rounded cursor-pointer">Submit Data</button>
            </div>
        </form>
    </div>
    <?php
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Handle file upload
    if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
        $targetDir = "uploads/";
        $targetFile = $targetDir . basename($_FILES["file"]["name"]);
        
        // Move uploaded file to target directory
        if (move_uploaded_file($_FILES["file"]["tmp_name"], $targetFile)) {
            echo "<script>
                    Swal.fire('Success!', 'File uploaded successfully', 'success').then(() => {
                        window.location = 'your_redirect_page.php'; // Redirect to a specific page after success
                    });
                  </script>";
        } else {
            echo "<script>
                    Swal.fire('Error!', 'Sorry, there was an error uploading your file.', 'error');
                  </script>";
        }
    }

    // Database connection (replace with your database credentials)
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "landblocking_db";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get other form data
    $landArea = $_POST['land_area'];
    $blocksNeeded = $_POST['blocks_needed'];

    // Prepare SQL statement to insert data into database
    $sql = "INSERT INTO LandDetails (land_area, blocks_needed, image_path) VALUES ('$landArea', '$blocksNeeded', '$targetFile')";

    if ($conn->query($sql) === TRUE) {
        // If query execution is successful, display a success message using JavaScript alert
        echo "<script>
                alert('Record created successfully');
              </script>";
    } else {
        // If there was an error executing the query, display an error message with details
        echo "<script>
                alert('Error: " . $sql . '\\n' . $conn->error . "');
              </script>";
    }

    // Close database connection
    $conn->close();
}
?>

</body>

</html>
